import { supabase } from "../supabase/client";

type SignInOptions = {
  redirect_uri?: string;
};

// Thin OAuth wrapper using Supabase directly.
// Configure your OAuth providers in Supabase Dashboard → Authentication → Providers.
export const purelabel = {
  auth: {
    signInWithOAuth: async (provider: "google" | "apple" | "microsoft", opts?: SignInOptions) => {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: provider as "google",
        options: {
          redirectTo: opts?.redirect_uri || (typeof window !== "undefined" ? window.location.origin : ""),
        },
      });
      if (error) return { error };
      // Supabase handles the redirect automatically
      return { redirected: true };
    },
  },
};

// Keep legacy export name for backward compatibility
export const lovable = purelabel;
