import { Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { HealthScoreRing } from "@/components/product/HealthScoreRing";

type Product = {
  id: string;
  name: string;
  brand: string | null;
  health_score: number | null;
  grade: string | null;
  summary: string | null;
  flags: string[];
  created_at: string;
};

export function ProductCard({ product }: { product: Product }) {
  return (
    <Link to="/products/$id" params={{ id: product.id }} className="block">
      <Card className="group h-full p-5 transition hover:shadow-elevated">
        <div className="flex items-start gap-4">
          <HealthScoreRing score={product.health_score ?? 0} grade={product.grade ?? "?"} size={64} />
          <div className="min-w-0 flex-1">
            <h3 className="truncate font-semibold text-ink">{product.name}</h3>
            {product.brand && <p className="truncate text-xs text-muted-foreground">{product.brand}</p>}
            <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{product.summary}</p>
          </div>
        </div>
        {product.flags?.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-1.5">
            {product.flags.slice(0, 3).map((f) => (
              <Badge key={f} variant="secondary" className="rounded-full text-[10px] font-medium">
                {f.replaceAll("_", " ")}
              </Badge>
            ))}
          </div>
        )}
      </Card>
    </Link>
  );
}
