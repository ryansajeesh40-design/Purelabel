import { cn } from "@/lib/utils";

export function HealthScoreRing({
  score,
  grade,
  size = 88,
  className,
}: {
  score: number;
  grade: string;
  size?: number;
  className?: string;
}) {
  const clamped = Math.max(0, Math.min(100, score));
  const stroke = Math.max(4, Math.round(size * 0.09));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (clamped / 100) * c;

  const color =
    clamped >= 80 ? "oklch(0.62 0.13 150)" :
    clamped >= 60 ? "oklch(0.72 0.13 110)" :
    clamped >= 40 ? "oklch(0.78 0.15 80)" :
                    "oklch(0.62 0.21 27)";

  return (
    <div className={cn("relative inline-flex shrink-0", className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--color-muted)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2} cy={size / 2} r={r}
          stroke={color} strokeWidth={stroke} fill="none"
          strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 600ms ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-lg font-bold leading-none text-ink" style={{ fontSize: size * 0.26 }}>{grade}</span>
        <span className="mt-0.5 text-[10px] font-medium text-muted-foreground">{clamped}</span>
      </div>
    </div>
  );
}
