import { cn } from "@/lib/utils";

export function Logo({ className, size = 40 }: { className?: string; size?: number }) {
  return (
    <div
      className={cn(
        "inline-flex items-center justify-center rounded-full text-sage-foreground shadow-sm",
        className,
      )}
      style={{ width: size, height: size, backgroundColor: "var(--color-sage)" }}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" width={size * 0.55} height={size * 0.55} fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 3a9 9 0 0 1 7.5 14L12 12V3Z" />
        <path d="M12 21a9 9 0 0 1-7.5-14L12 12v9Z" />
        <circle cx="12" cy="12" r="2.2" />
      </svg>
    </div>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <Logo size={32} />
      <span className="font-display text-lg font-bold tracking-tight text-ink">PureLabel</span>
    </div>
  );
}
