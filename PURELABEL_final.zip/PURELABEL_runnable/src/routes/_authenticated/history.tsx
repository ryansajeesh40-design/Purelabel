import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { listProducts } from "@/lib/scan.functions";
import { Input } from "@/components/ui/input";
import { ProductCard } from "@/components/product/ProductCard";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, ScanLine } from "lucide-react";

export const Route = createFileRoute("/_authenticated/history")({
  head: () => ({
    meta: [
      { title: "History — PureLabel" },
      { name: "description", content: "Every label you've scanned, scored and saved." },
    ],
  }),
  component: HistoryPage,
});

function HistoryPage() {
  const fn = useServerFn(listProducts);
  const { data = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: () => fn() });
  const [q, setQ] = useState("");

  const filtered = data.filter((p) =>
    !q || (p.name + " " + (p.brand ?? "")).toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-ink">History</h1>
          <p className="mt-1 text-muted-foreground">{data.length} scan{data.length === 1 ? "" : "s"}</p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products" className="h-10 rounded-xl pl-9" />
        </div>
      </header>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : filtered.length === 0 ? (
        <Card className="flex flex-col items-center p-12 text-center">
          <ScanLine className="size-10 text-muted-foreground" />
          <p className="mt-3 font-semibold">{data.length === 0 ? "No scans yet" : "No matches"}</p>
          {data.length === 0 && (
            <Button asChild className="mt-5 rounded-xl"><Link to="/scan">Scan your first label</Link></Button>
          )}
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}
