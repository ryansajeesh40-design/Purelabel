import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { analyzeLabel } from "@/lib/scan.functions";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Camera, Upload, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/_authenticated/scan")({
  head: () => ({
    meta: [
      { title: "Scan a label — PureLabel" },
      { name: "description", content: "Upload an ingredient label photo for instant AI analysis." },
    ],
  }),
  component: ScanPage,
});

function ScanPage() {
  const fileInput = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const analyze = useServerFn(analyzeLabel);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function onFile(file: File) {
    if (!file.type.startsWith("image/")) return toast.error("Please choose an image file.");
    if (file.size > 8 * 1024 * 1024) return toast.error("Image must be under 8MB.");
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result as string);
      r.onerror = () => reject(r.error);
      r.readAsDataURL(file);
    });
    setPreview(dataUrl);
  }

  async function runAnalysis() {
    if (!preview) return;
    setLoading(true);
    try {
      const { id } = await analyze({ data: { imageDataUrl: preview } });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      toast.success("Analysis complete");
      navigate({ to: "/products/$id", params: { id } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to analyze");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-ink">Scan a label</h1>
        <p className="mt-2 text-muted-foreground">
          Snap a clear photo of the ingredients panel. Our AI does the rest in seconds.
        </p>
      </header>

      <Card className="overflow-hidden p-0">
        {preview ? (
          <div className="relative">
            <img src={preview} alt="Selected label" className="w-full max-h-[420px] object-contain bg-muted" />
            <button
              onClick={() => setPreview(null)}
              aria-label="Remove image"
              className="absolute right-3 top-3 inline-flex size-9 items-center justify-center rounded-full bg-card/90 backdrop-blur hover:bg-card"
            >
              <X className="size-4" />
            </button>
          </div>
        ) : (
          <div className="grid gap-3 p-8 sm:grid-cols-2">
            <UploadTile
              icon={<Camera className="size-6" />}
              title="Take a photo"
              hint="Use your camera"
              onClick={() => cameraInput.current?.click()}
            />
            <UploadTile
              icon={<Upload className="size-6" />}
              title="Upload image"
              hint="JPG, PNG up to 8MB"
              onClick={() => fileInput.current?.click()}
            />
          </div>
        )}

        <input
          ref={fileInput} type="file" accept="image/*" className="hidden"
          onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
        />
        <input
          ref={cameraInput} type="file" accept="image/*" capture="environment" className="hidden"
          onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
        />
      </Card>

      {preview && (
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => setPreview(null)} disabled={loading} className="rounded-xl">
            Choose different
          </Button>
          <Button onClick={runAnalysis} disabled={loading} className="ml-auto rounded-xl">
            {loading && <Loader2 className="mr-2 size-4 animate-spin" />}
            {loading ? "Analyzing…" : "Analyze label"}
          </Button>
        </div>
      )}
    </div>
  );
}

function UploadTile({ icon, title, hint, onClick }: { icon: React.ReactNode; title: string; hint: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group flex flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-border bg-muted/40 p-8 text-center transition hover:border-sage hover:bg-accent/60"
    >
      <div className="flex size-12 items-center justify-center rounded-full bg-sage text-sage-foreground">{icon}</div>
      <p className="mt-2 font-semibold text-ink">{title}</p>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </button>
  );
}
