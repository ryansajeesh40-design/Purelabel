import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { Suspense } from "react";
import { listProducts } from "@/lib/scan.functions";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ScanLine, Sparkles, History as HistoryIcon } from "lucide-react";
import { ProductCard } from "@/components/product/ProductCard";

const productsQO = (fn: ReturnType<typeof useServerFn<typeof listProducts>>) =>
  queryOptions({ queryKey: ["products"], queryFn: () => fn() });

export const Route = createFileRoute("/_authenticated/")({
  head: () => ({
    meta: [
      { title: "Dashboard — PureLabel" },
      { name: "description", content: "Your recent ingredient scans and health insights." },
    ],
  }),
  component: Dashboard,
  errorComponent: ({ error }) => <p className="text-destructive">{error.message}</p>,
  notFoundComponent: () => <p>Not found</p>,
});

function Dashboard() {
  return (
    <div className="space-y-8">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm font-medium text-sage">Welcome back</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight text-ink sm:text-4xl">What's in your basket today?</h1>
          <p className="mt-2 max-w-xl text-muted-foreground">
            Snap a label to instantly see ingredients, allergens, additives and a health score tailored to your preferences.
          </p>
        </div>
        <Button asChild size="lg" className="rounded-xl">
          <Link to="/scan"><ScanLine className="size-4" /> Scan a label</Link>
        </Button>
      </header>

      <section className="grid gap-4 sm:grid-cols-3">
        <FeatureTile icon={<ScanLine />} title="Scan in seconds" body="Snap or upload a label. Our AI reads ingredients, additives and allergens." />
        <FeatureTile icon={<Sparkles />} title="Personalized scoring" body="Set dietary flags and allergens — scores adapt to what matters to you." />
        <FeatureTile icon={<HistoryIcon />} title="Build a clean pantry" body="Save scans, compare products and shop smarter every week." />
      </section>

      <section>
        <div className="mb-4 flex items-end justify-between">
          <h2 className="text-xl font-semibold text-ink">Recent scans</h2>
          <Link to="/history" className="text-sm font-medium text-muted-foreground hover:text-foreground">View all →</Link>
        </div>
        <Suspense fallback={<GridSkeleton />}><RecentScans /></Suspense>
      </section>
    </div>
  );
}

function RecentScans() {
  const fn = useServerFn(listProducts);
  const { data } = useSuspenseQuery(productsQO(fn));
  if (data.length === 0) {
    return (
      <Card className="flex flex-col items-center justify-center p-12 text-center">
        <ScanLine className="size-10 text-muted-foreground" />
        <h3 className="mt-4 text-lg font-semibold">No scans yet</h3>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">
          Scan your first product to get an instant ingredient breakdown.
        </p>
        <Button asChild className="mt-6 rounded-xl"><Link to="/scan">Start scanning</Link></Button>
      </Card>
    );
  }
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {data.slice(0, 6).map((p) => <ProductCard key={p.id} product={p} />)}
    </div>
  );
}

function FeatureTile({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <Card className="p-5">
      <div className="flex size-10 items-center justify-center rounded-xl bg-accent text-sage">{icon}</div>
      <h3 className="mt-4 font-semibold text-ink">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{body}</p>
    </Card>
  );
}

function GridSkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {[0, 1, 2].map((i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
    </div>
  );
}
