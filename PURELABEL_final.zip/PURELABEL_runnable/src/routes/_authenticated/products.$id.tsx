import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { getProduct, deleteProduct } from "@/lib/scan.functions";
import { listMessages, sendMessage } from "@/lib/chat.functions";
import { HealthScoreRing } from "@/components/product/HealthScoreRing";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Trash2, Send, Loader2, ShieldCheck, ShieldAlert, ShieldX } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/products/$id")({
  head: ({ params }) => ({
    meta: [
      { title: "Product — PureLabel" },
      { name: "description", content: "Detailed ingredient analysis." },
      { property: "og:url", content: `/products/${params.id}` },
    ],
  }),
  component: ProductPage,
  errorComponent: ({ error }) => <p className="text-destructive">{error.message}</p>,
  notFoundComponent: () => <p>Product not found</p>,
});

function ProductPage() {
  const { id } = Route.useParams();
  const getFn = useServerFn(getProduct);
  const delFn = useServerFn(deleteProduct);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: () => getFn({ data: { id } }),
  });

  const delMut = useMutation({
    mutationFn: () => delFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Deleted");
      queryClient.invalidateQueries({ queryKey: ["products"] });
      navigate({ to: "/history" });
    },
  });

  if (isLoading) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="size-6 animate-spin text-muted-foreground" /></div>;
  }
  if (!product) return <p>Product not found.</p>;

  const ingredients = (product.ingredients as Array<{ name: string; verdict: "safe" | "caution" | "avoid"; category?: string; note?: string }>) ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <Button asChild variant="ghost" size="sm" className="text-muted-foreground"><Link to="/history"><ArrowLeft className="size-4" /> Back</Link></Button>
        <Button variant="ghost" size="sm" onClick={() => confirm("Delete this scan?") && delMut.mutate()} className="text-muted-foreground hover:text-destructive">
          <Trash2 className="size-4" /> Delete
        </Button>
      </div>

      <Card className="overflow-hidden p-6 sm:p-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
          <HealthScoreRing score={product.health_score ?? 0} grade={product.grade ?? "?"} size={120} />
          <div className="min-w-0 flex-1">
            <h1 className="text-2xl font-bold tracking-tight text-ink sm:text-3xl">{product.name}</h1>
            {product.brand && <p className="mt-0.5 text-sm text-muted-foreground">{product.brand}</p>}
            <p className="mt-3 text-base text-foreground">{product.summary}</p>
            {(product.flags?.length ?? 0) > 0 && (
              <div className="mt-4 flex flex-wrap gap-1.5">
                {product.flags!.map((f) => <Badge key={f} variant="secondary" className="rounded-full">{f.replaceAll("_", " ")}</Badge>)}
              </div>
            )}
          </div>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-ink">Ingredients ({ingredients.length})</h2>
            <ul className="mt-4 divide-y divide-border">
              {ingredients.map((i, idx) => (
                <li key={idx} className="flex items-start gap-3 py-3">
                  <VerdictIcon v={i.verdict} />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-foreground">{i.name}</p>
                    {i.note && <p className="text-sm text-muted-foreground">{i.note}</p>}
                  </div>
                  {i.category && <span className="shrink-0 text-xs uppercase tracking-wide text-muted-foreground">{i.category}</span>}
                </li>
              ))}
            </ul>
          </Card>

          <div className="grid gap-4 sm:grid-cols-2">
            <InfoCard title="Allergens" items={product.allergens ?? []} empty="No common allergens detected" />
            <InfoCard title="Additives" items={product.additives ?? []} empty="No flagged additives" />
          </div>
        </div>

        <ChatPanel productId={id} />
      </div>
    </div>
  );
}

function VerdictIcon({ v }: { v: "safe" | "caution" | "avoid" }) {
  const map = {
    safe:    { Icon: ShieldCheck, cls: "bg-success/10 text-success" },
    caution: { Icon: ShieldAlert, cls: "bg-warning/15 text-warning-foreground" },
    avoid:   { Icon: ShieldX,     cls: "bg-destructive/10 text-destructive" },
  } as const;
  const { Icon, cls } = map[v] ?? map.caution;
  return <div className={cn("mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg", cls)}><Icon className="size-4" /></div>;
}

function InfoCard({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <Card className="p-5">
      <h3 className="font-semibold text-ink">{title}</h3>
      {items.length === 0 ? (
        <p className="mt-2 text-sm text-muted-foreground">{empty}</p>
      ) : (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {items.map((i) => <Badge key={i} variant="outline" className="rounded-full">{i}</Badge>)}
        </div>
      )}
    </Card>
  );
}

function ChatPanel({ productId }: { productId: string }) {
  const listFn = useServerFn(listMessages);
  const sendFn = useServerFn(sendMessage);
  const queryClient = useQueryClient();
  const [input, setInput] = useState("");

  const { data: messages = [] } = useQuery({
    queryKey: ["chat", productId],
    queryFn: () => listFn({ data: { productId } }),
  });

  const send = useMutation({
    mutationFn: (message: string) => sendFn({ data: { productId, message } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["chat", productId] }),
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim() || send.isPending) return;
    const text = input.trim();
    setInput("");
    send.mutate(text);
  }

  return (
    <Card className="flex h-[560px] flex-col p-0">
      <div className="border-b border-border p-4">
        <h2 className="font-semibold text-ink">Ask about this product</h2>
        <p className="text-xs text-muted-foreground">e.g. "Is this OK for a low-sugar diet?"</p>
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        {messages.length === 0 && !send.isPending && (
          <p className="text-sm text-muted-foreground">No questions yet. Ask anything about the ingredients.</p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
            <div className={cn(
              "max-w-[85%] whitespace-pre-wrap rounded-2xl px-3.5 py-2 text-sm",
              m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground",
            )}>{m.content}</div>
          </div>
        ))}
        {send.isPending && (
          <div className="flex justify-start">
            <div className="rounded-2xl bg-muted px-3.5 py-2 text-sm text-muted-foreground"><Loader2 className="inline size-3 animate-spin" /> Thinking…</div>
          </div>
        )}
      </div>
      <form onSubmit={submit} className="flex items-center gap-2 border-t border-border p-3">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask a question…"
          disabled={send.isPending}
          className="h-10 rounded-xl"
        />
        <Button type="submit" size="icon" disabled={!input.trim() || send.isPending} className="size-10 rounded-xl shrink-0" aria-label="Send">
          <Send className="size-4" />
        </Button>
      </form>
    </Card>
  );
}
