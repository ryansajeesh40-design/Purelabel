import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getPreferences, updatePreferences } from "@/lib/prefs.functions";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/preferences")({
  head: () => ({
    meta: [
      { title: "Preferences — PureLabel" },
      { name: "description", content: "Tune your dietary preferences for personalized scoring." },
    ],
  }),
  component: PreferencesPage,
});

const DIETS = ["vegan", "vegetarian", "gluten_free", "dairy_free", "keto", "halal", "kosher", "pescatarian"];
const ALLERGENS = ["peanut", "tree_nut", "dairy", "gluten", "soy", "egg", "fish", "shellfish", "sesame"];

function PreferencesPage() {
  const getFn = useServerFn(getPreferences);
  const setFn = useServerFn(updatePreferences);
  const queryClient = useQueryClient();

  const { data } = useQuery({ queryKey: ["prefs"], queryFn: () => getFn() });

  const [diets, setDiets] = useState<string[]>([]);
  const [allergens, setAllergens] = useState<string[]>([]);
  const [avoidAdd, setAvoidAdd] = useState(true);
  const [avoidSeed, setAvoidSeed] = useState(false);
  const [avoidSugar, setAvoidSugar] = useState(false);

  useEffect(() => {
    if (data) {
      setDiets(data.dietary_flags ?? []);
      setAllergens(data.allergens ?? []);
      setAvoidAdd(data.avoid_additives);
      setAvoidSeed(data.avoid_seed_oils);
      setAvoidSugar(data.avoid_added_sugar);
    }
  }, [data]);

  const save = useMutation({
    mutationFn: () =>
      setFn({
        data: {
          dietary_flags: diets,
          allergens,
          avoid_additives: avoidAdd,
          avoid_seed_oils: avoidSeed,
          avoid_added_sugar: avoidSugar,
        },
      }),
    onSuccess: () => {
      toast.success("Preferences saved");
      queryClient.invalidateQueries({ queryKey: ["prefs"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Save failed"),
  });

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-ink">Preferences</h1>
        <p className="mt-2 text-muted-foreground">PureLabel adjusts scores based on what matters to you.</p>
      </header>

      <Card className="p-6">
        <h2 className="font-semibold text-ink">Diet</h2>
        <p className="mt-1 text-sm text-muted-foreground">Select all that apply.</p>
        <ChipGroup options={DIETS} value={diets} onChange={setDiets} />
      </Card>

      <Card className="p-6">
        <h2 className="font-semibold text-ink">Allergens to avoid</h2>
        <ChipGroup options={ALLERGENS} value={allergens} onChange={setAllergens} />
      </Card>

      <Card className="space-y-4 p-6">
        <h2 className="font-semibold text-ink">Ingredients to flag</h2>
        <Toggle id="avoidAdd" label="Artificial additives & colors" checked={avoidAdd} onChange={setAvoidAdd} />
        <Toggle id="avoidSeed" label="Seed & vegetable oils" checked={avoidSeed} onChange={setAvoidSeed} />
        <Toggle id="avoidSugar" label="Added sugar" checked={avoidSugar} onChange={setAvoidSugar} />
      </Card>

      <div className="flex justify-end">
        <Button onClick={() => save.mutate()} disabled={save.isPending} className="rounded-xl">
          {save.isPending ? "Saving…" : "Save preferences"}
        </Button>
      </div>
    </div>
  );
}

function ChipGroup({ options, value, onChange }: { options: string[]; value: string[]; onChange: (v: string[]) => void }) {
  function toggle(o: string) {
    onChange(value.includes(o) ? value.filter((v) => v !== o) : [...value, o]);
  }
  return (
    <div className="mt-4 flex flex-wrap gap-2">
      {options.map((o) => {
        const active = value.includes(o);
        return (
          <button
            key={o}
            type="button"
            onClick={() => toggle(o)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-sm font-medium transition",
              active
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-muted-foreground hover:border-foreground hover:text-foreground",
            )}
          >
            {o.replaceAll("_", " ")}
          </button>
        );
      })}
    </div>
  );
}

function Toggle({ id, label, checked, onChange }: { id: string; label: string; checked: boolean; onChange: (b: boolean) => void }) {
  return (
    <div className="flex items-center justify-between">
      <Label htmlFor={id} className="text-sm font-medium">{label}</Label>
      <Switch id={id} checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
