import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { getProfile, updateProfile } from "@/lib/prefs.functions";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({
    meta: [
      { title: "Account — PureLabel" },
      { name: "description", content: "Manage your PureLabel account." },
    ],
  }),
  component: AccountPage,
});

function AccountPage() {
  const getFn = useServerFn(getProfile);
  const setFn = useServerFn(updateProfile);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data } = useQuery({ queryKey: ["profile"], queryFn: () => getFn() });
  const [name, setName] = useState("");

  useEffect(() => {
    if (data?.profile?.display_name) setName(data.profile.display_name);
  }, [data]);

  const save = useMutation({
    mutationFn: () => setFn({ data: { display_name: name } }),
    onSuccess: () => {
      toast.success("Profile saved");
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Save failed"),
  });

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-ink">Account</h1>
        <p className="mt-2 text-muted-foreground">Manage your profile and session.</p>
      </header>

      <Card className="space-y-4 p-6">
        <div className="space-y-1.5">
          <Label htmlFor="email">Email</Label>
          <Input id="email" value={data?.email ?? ""} disabled className="h-11 rounded-xl" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="name">Display name</Label>
          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="h-11 rounded-xl" />
        </div>
        <div className="flex justify-end">
          <Button onClick={() => save.mutate()} disabled={save.isPending || !name.trim()} className="rounded-xl">
            {save.isPending ? "Saving…" : "Save"}
          </Button>
        </div>
      </Card>

      <Card className="flex items-center justify-between p-6">
        <div>
          <h3 className="font-semibold text-ink">Sign out</h3>
          <p className="text-sm text-muted-foreground">End your current session.</p>
        </div>
        <Button variant="outline" onClick={signOut} className="rounded-xl">Sign out</Button>
      </Card>
    </div>
  );
}
