import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const AnalyzeInput = z.object({
  imageDataUrl: z.string().min(20),
  preferencesNote: z.string().max(800).optional(),
});

type AnalyzeResult = {
  productName: string;
  brand: string | null;
  summary: string;
  healthScore: number;
  grade: "A" | "B" | "C" | "D" | "F";
  ingredients: { name: string; verdict: "safe" | "caution" | "avoid"; category?: string; note?: string }[];
  allergens: string[];
  additives: string[];
  flags: string[];
  rawText: string;
};

export const analyzeLabel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AnalyzeInput.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.AI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");

    const system = `You are PureLabel, an expert food-science analyst. Given a photo of a packaged food label, you:
1) OCR the ingredient list, brand, and product name from the image.
2) Classify each ingredient as "safe" (whole-food / generally benign), "caution" (e.g. added sugar, refined oils, common emulsifiers), or "avoid" (artificial colors, trans fats, suspicious additives).
3) Detect allergens (peanut, tree nut, dairy, gluten, soy, egg, fish, shellfish, sesame).
4) Detect ultra-processing flags (e.g. ultra_processed, contains_seed_oils, high_added_sugar, contains_artificial_colors, contains_trans_fat).
5) Score the product 0-100 (higher = cleaner) and assign a letter grade A-F.
6) Write a one-sentence summary in plain English.
${data.preferencesNote ? "User preferences: " + data.preferencesNote : ""}
Return ONLY via the analyze_label tool.`;

    const tool = {
      type: "function",
      function: {
        name: "analyze_label",
        description: "Return structured ingredient analysis.",
        parameters: {
          type: "object",
          properties: {
            productName: { type: "string" },
            brand: { type: "string" },
            summary: { type: "string" },
            healthScore: { type: "number" },
            grade: { type: "string", enum: ["A", "B", "C", "D", "F"] },
            ingredients: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  verdict: { type: "string", enum: ["safe", "caution", "avoid"] },
                  category: { type: "string" },
                  note: { type: "string" },
                },
                required: ["name", "verdict"],
                additionalProperties: false,
              },
            },
            allergens: { type: "array", items: { type: "string" } },
            additives: { type: "array", items: { type: "string" } },
            flags: { type: "array", items: { type: "string" } },
            rawText: { type: "string", description: "All text OCR'd from the label" },
          },
          required: ["productName", "summary", "healthScore", "grade", "ingredients", "allergens", "additives", "flags", "rawText"],
          additionalProperties: false,
        },
      },
    };

    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://purelabel.app",
        "X-Title": "PureLabel",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: system },
          {
            role: "user",
            content: [
              { type: "text", text: "Analyze this food label." },
              { type: "image_url", image_url: { url: data.imageDataUrl } },
            ],
          },
        ],
        tools: [tool],
        tool_choice: { type: "function", function: { name: "analyze_label" } },
      }),
    });

    if (res.status === 429) throw new Error("Rate limit reached. Please try again in a moment.");
    if (res.status === 402) throw new Error("AI credits exhausted. Add credits to continue.");
    if (!res.ok) {
      const txt = await res.text();
      console.error("AI gateway error", res.status, txt);
      throw new Error("Failed to analyze label");
    }

    const json = await res.json();
    const call = json.choices?.[0]?.message?.tool_calls?.[0];
    if (!call?.function?.arguments) throw new Error("Empty AI response");
    const parsed = JSON.parse(call.function.arguments) as AnalyzeResult;

    const { data: row, error } = await context.supabase
      .from("products")
      .insert({
        user_id: context.userId,
        name: parsed.productName || "Untitled product",
        brand: parsed.brand || null,
        summary: parsed.summary,
        health_score: Math.max(0, Math.min(100, Math.round(parsed.healthScore))),
        grade: parsed.grade,
        ingredients: parsed.ingredients as unknown as never,
        allergens: parsed.allergens,
        additives: parsed.additives,
        flags: parsed.flags,
        raw_text: parsed.rawText,
        status: "complete",
      })
      .select("id")
      .single();
    if (error) throw error;
    return { id: row.id };
  });

export const listProducts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("products")
      .select("id, name, brand, health_score, grade, summary, flags, created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw error;
    return data ?? [];
  });

export const getProduct = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("products")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw error;
    if (!row) throw new Error("Not found");
    return row;
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("products").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });
