import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const listMessages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ productId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("chat_messages")
      .select("id, role, content, created_at")
      .eq("product_id", data.productId)
      .order("created_at", { ascending: true });
    if (error) throw error;
    return rows ?? [];
  });

const SendSchema = z.object({
  productId: z.string().uuid(),
  message: z.string().min(1).max(2000),
});

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SendSchema.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.AI_API_KEY;
    if (!apiKey) throw new Error("AI not configured");

    const { data: product, error: pErr } = await context.supabase
      .from("products")
      .select("name, brand, summary, ingredients, allergens, additives, flags, health_score, grade, raw_text")
      .eq("id", data.productId)
      .maybeSingle();
    if (pErr || !product) throw new Error("Product not found");

    const { data: history } = await context.supabase
      .from("chat_messages")
      .select("role, content")
      .eq("product_id", data.productId)
      .order("created_at", { ascending: true })
      .limit(30);

    await context.supabase.from("chat_messages").insert({
      product_id: data.productId,
      user_id: context.userId,
      role: "user",
      content: data.message,
    });

    const system = `You are PureLabel, a helpful food-science assistant. Answer concisely about the product below. Be honest, cite specific ingredients when relevant.

Product: ${product.name}${product.brand ? " by " + product.brand : ""}
Score: ${product.health_score}/100 (Grade ${product.grade})
Summary: ${product.summary}
Ingredients: ${JSON.stringify(product.ingredients)}
Allergens: ${(product.allergens ?? []).join(", ") || "none"}
Flags: ${(product.flags ?? []).join(", ") || "none"}`;

    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://purelabel.app",
        "X-Title": "PureLabel",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: system },
          ...(history ?? []).map((m) => ({ role: m.role, content: m.content })),
          { role: "user", content: data.message },
        ],
      }),
    });

    if (res.status === 429) throw new Error("Rate limit reached. Try again in a moment.");
    if (res.status === 402) throw new Error("AI credits exhausted.");
    if (!res.ok) throw new Error("AI request failed");

    const json = await res.json();
    const reply: string = json.choices?.[0]?.message?.content ?? "Sorry, I don't have an answer.";

    await context.supabase.from("chat_messages").insert({
      product_id: data.productId,
      user_id: context.userId,
      role: "assistant",
      content: reply,
    });

    return { reply };
  });
